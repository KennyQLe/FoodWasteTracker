[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-7f7980b617ed060a017424585567c406b6ee15c891e84e1186181d67ecf80aa0.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=12816492)
#Food Wastage Tracker Project

Welcome to the Food Wastage Tracker project! 

This project is intended to give you the opportunity to practice the concepts that your learned in CPSC 121.

See the [Project Guide](https://tinyurl.com/cpsc121-f23-project-guide) for detailed instructions.