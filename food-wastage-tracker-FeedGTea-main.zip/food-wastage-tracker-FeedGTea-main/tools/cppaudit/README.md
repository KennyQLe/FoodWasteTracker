# CPPAudit

CPPAudit is an application that facilitates the evaluation of C++ code. Specifically, it offers an easy way to create unit tests, run code against unit tests, check the coding style (using the clang-tidy linter), and coding format (using clang-format).
